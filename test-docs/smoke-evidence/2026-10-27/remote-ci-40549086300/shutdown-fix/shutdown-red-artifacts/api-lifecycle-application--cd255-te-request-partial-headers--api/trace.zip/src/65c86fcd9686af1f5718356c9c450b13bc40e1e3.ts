import { test, expect, ownedDatabase } from '../fixtures/app.js';
import { createApplication } from '../../app/api/application.js';
import { connect, type Socket, type AddressInfo } from 'node:net';
import { once } from 'node:events';
import { DatabaseSync } from 'node:sqlite';

async function listeningApplication() {
  const dbPath = ownedDatabase();
  const app = createApplication({ dbPath });
  await new Promise<void>(resolveReady => app.server.listen(0, '127.0.0.1', resolveReady));
  return { app, dbPath, port: (app.server.address() as AddressInfo).port };
}

async function acceptedSocket(app: ReturnType<typeof createApplication>, port: number) {
  // A client-side connect event alone does not prove the server owns the socket yet.
  const accepted = once(app.server, 'connection');
  const socket = connect(port, '127.0.0.1');
  const [[serverSocket]] = await Promise.all([accepted, once(socket, 'connect')]);
  return { socket, serverSocket: serverSocket as Socket };
}

for (const prefix of ['', 'GET /api/games HTTP/1.1\r\nHost:']) {
  test(`application shutdown releases an accepted socket without a complete request (${prefix ? 'partial headers' : 'browser preconnect'})`, async () => {
    const { app, port } = await listeningApplication();
    const { socket, serverSocket } = await acceptedSocket(app, port);
    socket.resume();
    try {
      if (prefix) {
        const received = once(serverSocket, 'data');
        socket.write(prefix);
        await received;
      }
      let closed = false;
      const stopped = app.close().then(() => { closed = true; });
      await expect.poll(() => closed, { timeout: 2000 }).toBe(true);
      await stopped;
      await expect.poll(() => socket.destroyed).toBe(true);
      expect(app.server.listening).toBe(false);
    } finally {
      socket.destroy();
      await app.close();
    }
  });
}

test('application shutdown drains a received feedback body and response while releasing an unused socket', async () => {
  const { app, dbPath, port } = await listeningApplication();
  const { socket: unused } = await acceptedSocket(app, port);
  const { socket: active } = await acceptedSocket(app, port);
  unused.resume();
  let response = '';
  active.setEncoding('utf8');
  active.on('data', chunk => { response += chunk; });
  const responseEnded = once(active, 'end');
  const input = { gameId: 1, email: '  player@example.com  ', description: '  Synthetic feedback during shutdown  ' };
  const body = JSON.stringify(input);
  const received = new Promise<void>(resolveReceived => app.server.once('request', request => {
    request.once('data', () => resolveReceived());
  }));
  try {
    active.write(`POST /api/feedback HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: ${Buffer.byteLength(body)}\r\n\r\n${body.slice(0, 12)}`);
    await received;
    let closed = false;
    const stopped = app.close().then(() => { closed = true; });
    expect(app.server.listening).toBe(false);
    active.end(body.slice(12));
    await responseEnded;
    await expect.poll(() => closed, { timeout: 2000 }).toBe(true);
    await stopped;
    expect(response).toMatch(/^HTTP\/1\.1 201 /);
    const { id } = JSON.parse(response.split('\r\n\r\n')[1]!) as { id: number };
    expect(Number.isSafeInteger(id) && id > 0).toBe(true);
    const db = new DatabaseSync(dbPath);
    try {
      expect(db.prepare('SELECT id,game_id,email,description FROM feedback').all()).toEqual([
        { id, game_id: 1, email: 'player@example.com', description: 'Synthetic feedback during shutdown' },
      ]);
      db.exec('BEGIN EXCLUSIVE; ROLLBACK;');
    } finally { db.close(); }
    await expect.poll(() => unused.destroyed).toBe(true);
  } finally {
    active.destroy();
    unused.destroy();
    await app.close();
  }
});
